
#!/bin/bash
# Helper: run locally to build debug APK
npm install
npm run build
npm install @capacitor/cli @capacitor/core --no-save
npx cap add android || true
npx cap copy || true
cd android
chmod +x ./gradlew
./gradlew assembleDebug
